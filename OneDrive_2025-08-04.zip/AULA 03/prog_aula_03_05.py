# Escreva um programa que, dados 3 números inteiros (n1, n2 e n3), diga qual deles é maior.

# Entrada dos dados
n1 = int(input('Informe o Primeiro Valor: '))
n2 = int(input('Informe o Segundo Valor: '))
n3 = int(input('Informe o Terceiro Valor: '))

# Saída dos dados
if n1 > n2 and n1 > n3:
    print(f'O Número {n1} é o maior valor')
else:
    if n2 > n1 and n2 > n3:
        print(f'O Número {n2} é o maior valor')
    else:
        if n3 > n1 and n3 > n2:
            print(f'O Número {n3} é o maior valor')
        else:
            print('Verifique os Valores Informados')

