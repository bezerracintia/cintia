# Escreva um programa que informe se um estudante está APROVADO ou REPROVADO.

# Entrada dos dados
nome = input('Informe o nome do estudante: ')
n1 = float(input('Informe a primeira nota: '))
n2 = float(input('Informe a segunda nota: '))

# Processamento dos dados
media = (n1 + n2) / 2

# Saída dos dados
if media >= 7:
    print(f'Sr(a) {nome}, a sua média foi {media}, portanto você está APROVADO(A)')
else:
    print(f'Sr(a) {nome}, a sua média foi {media}, portanto você está REPROVADO(A)')