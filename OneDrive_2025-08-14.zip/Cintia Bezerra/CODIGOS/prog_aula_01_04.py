# Escreva um programa que leia um valor inteiro e apresente os resultados do quadrado e do cubo do valor lido

#Entrada dos dados
num=int(input('informe um valor inteiro'))

#Processamento de dados
quad=num=**2
cubo=num=***3

#saída dos dados
print('o quadrado é:',quad)
print('o cubo é:',cubo)

