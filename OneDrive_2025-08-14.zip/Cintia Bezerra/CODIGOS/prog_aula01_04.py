-# Escreva um programa que, leia dois valores para as variáveis A e B e efetue a troca dos valores de forma que a variável A passe a possuir o valor da variável B e a variável B passe a possuir o valor da variável A

#Entrada dos dados
a=int(input('informe um valor para variavel A:'))
B=int(input('informe um valorpara variavel B:'))
#processamentos de dados
aux=a
a=B
b=aux
#saida de dados
print('o valor da variavel A é,'a)
print('ovalorda variavel B é:',b)
