#Faça um programa que leia uma temperatura em graus Celsius e apresente-a convertida em graus Fahrenheit A fórmula de conversão é: F = (9 * C + 160) / 5, na qual F é a temperatura em Fahrenheit e C é a temperatura em Celsius;

#Entrada dos dados
c = float(input('informe a temperatura em graus Celsius:'))

#Proceessamento dos dados 
f = (9 * c + 160) / 5

#saida dos dados
print(F'a temperatura em graus Fahrenheit é {F} 36º')