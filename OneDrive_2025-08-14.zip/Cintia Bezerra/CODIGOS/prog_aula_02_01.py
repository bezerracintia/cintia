#Crie um programa que calcule a idade de uma pessoa a partir do ano de nascimento dela
nasc = int(input('digite o ano de nascimento:'))
ano = int(input('digite o ano atual'))  
idade = ano - nasc
print(f'a sua idade é{idade} anos.')
